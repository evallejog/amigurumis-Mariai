import React, { useEffect, useRef, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Info, Loader2 } from 'lucide-react';

declare global {
  interface Window {
    google?: {
      accounts?: {
        id?: {
          initialize: (config: any) => void;
          renderButton: (parent: HTMLElement, options: any) => void;
          prompt: (momentListener?: (notification: any) => void) => void;
          disableAutoSelect?: () => void;
        };
      };
    };
  }
}

interface GoogleSignInButtonProps {
  onError?: (msg: string) => void;
}

export const GoogleSignInButton: React.FC<GoogleSignInButtonProps> = ({ onError }) => {
  const { googleClientId, isGoogleConfigured, loginWithGoogleCredential } = useAuth();
  const buttonContainerRef = useRef<HTMLDivElement>(null);
  const [isVerifying, setIsVerifying] = useState(false);
  const [originNotice, setOriginNotice] = useState<string | null>(null);

  useEffect(() => {
    if (!isGoogleConfigured || !googleClientId) return;

    let isMounted = true;

    const initGsi = () => {
      if (!window.google?.accounts?.id || !buttonContainerRef.current) return;

      try {
        buttonContainerRef.current.innerHTML = '';
        window.google.accounts.id.initialize({
          client_id: googleClientId,
          callback: async (response: { credential?: string }) => {
            if (!response.credential) {
              const err = 'No se recibió la credencial de autenticación de Google.';
              if (onError) onError(err);
              return;
            }

            if (isMounted) setIsVerifying(true);
            try {
              const result = await loginWithGoogleCredential(response.credential);
              if (!result.success && onError) {
                onError(result.error || 'Error al verificar la credencial de Google.');
              }
            } catch (err: any) {
              if (onError) onError(err.message || 'Error en la conexión con el servidor.');
            } finally {
              if (isMounted) setIsVerifying(false);
            }
          },
          auto_select: false,
          cancel_on_tap_outside: true,
        });

        window.google.accounts.id.renderButton(buttonContainerRef.current, {
          theme: 'outline',
          size: 'large',
          text: 'continue_with',
          shape: 'rectangular',
          width: 320,
          logo_alignment: 'left',
          locale: 'es',
        });
      } catch (err: any) {
        console.warn('Error initializing Google Identity Services button:', err);
        setOriginNotice(
          `Si la ventana de Google no abre, asegúrate de que ${window.location.origin} esté en "Orígenes de JavaScript autorizados" en Google Cloud Console.`
        );
      }
    };

    if (window.google?.accounts?.id) {
      initGsi();
    } else {
      let attempts = 0;
      const interval = setInterval(() => {
        attempts++;
        if (window.google?.accounts?.id) {
          clearInterval(interval);
          initGsi();
        } else if (attempts >= 10) {
          clearInterval(interval);
        }
      }, 300);
      return () => clearInterval(interval);
    }

    return () => {
      isMounted = false;
    };
  }, [googleClientId, isGoogleConfigured]);

  if (!isGoogleConfigured) {
    return (
      <div className="p-3 rounded-2xl bg-amber-50/90 border border-amber-200/80 text-xs text-amber-900 space-y-1">
        <div className="flex items-center gap-2 font-bold text-[11px] text-amber-950">
          <Info className="w-4 h-4 text-amber-700 shrink-0" />
          <span>Inicio de sesión con Google (Configuración)</span>
        </div>
        <p className="text-[11px] text-amber-800 leading-relaxed">
          Para activar Google Identity Services, define la variable{' '}
          <code className="bg-amber-100/90 px-1 py-0.5 rounded font-mono text-[10px] text-amber-950 font-bold">
            GOOGLE_CLIENT_ID
          </code>{' '}
          en el entorno o en el panel de despliegue.
        </p>
      </div>
    );
  }

  return (
    <div className="w-full flex flex-col items-center justify-center space-y-2">
      {isVerifying ? (
        <div className="w-full py-2.5 px-4 rounded-xl bg-stone-100 border border-stone-300 text-stone-700 text-xs font-bold flex items-center justify-center gap-2">
          <Loader2 className="w-4 h-4 animate-spin text-amber-700" />
          <span>Verificando ID token de Google...</span>
        </div>
      ) : (
        <div
          ref={buttonContainerRef}
          className="w-full flex items-center justify-center min-h-[44px] overflow-hidden"
        />
      )}

      {originNotice && (
        <p className="text-[10px] text-stone-500 text-center leading-normal">
          {originNotice}
        </p>
      )}
    </div>
  );
};
