import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface User {
  id: string;
  email: string;
  fullName: string;
  phone?: string;
  address?: string;
  city?: string;
  department?: string;
  avatarUrl?: string;
  provider?: string;
  role: string;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isAuthModalOpen: boolean;
  authModalTab: 'login' | 'register';
  googleClientId: string | null;
  isGoogleConfigured: boolean;
  openAuthModal: (tab?: 'login' | 'register') => void;
  closeAuthModal: () => void;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  loginWithGoogleCredential: (credential: string) => Promise<{ success: boolean; error?: string }>;
  loginWithGoogleDemo: () => Promise<{ success: boolean; error?: string }>;
  register: (data: {
    email: string;
    password: string;
    fullName: string;
    phone?: string;
    address?: string;
    city?: string;
    department?: string;
  }) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const TOKEN_KEY = 'amigurumis_mariai_auth_token';

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [token, setToken] = useState<string | null>(() => {
    try {
      return localStorage.getItem(TOKEN_KEY);
    } catch {
      return null;
    }
  });
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalTab, setAuthModalTab] = useState<'login' | 'register'>('login');
  const [googleClientId, setGoogleClientId] = useState<string | null>(null);
  const [isGoogleConfigured, setIsGoogleConfigured] = useState<boolean>(false);

  // Fetch Google Client ID configuration from server on mount
  useEffect(() => {
    fetch('/api/auth/google/config')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.configured && data.clientId) {
          setGoogleClientId(data.clientId);
          setIsGoogleConfigured(true);
        } else {
          setGoogleClientId(null);
          setIsGoogleConfigured(false);
        }
      })
      .catch((err) => {
        console.warn('Could not fetch Google auth configuration:', err);
      });
  }, []);

  const openAuthModal = (tab: 'login' | 'register' = 'login') => {
    setAuthModalTab(tab);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  // Fetch current user if token exists or via HttpOnly cookie
  const fetchCurrentUser = async (authToken: string): Promise<User | null> => {
    try {
      const res = await fetch('/api/auth/me', {
        headers: authToken
          ? {
              Authorization: `Bearer ${authToken}`,
            }
          : undefined,
      });
      if (res.ok) {
        const data = await res.json();
        return data.user;
      } else {
        if (authToken) {
          localStorage.removeItem(TOKEN_KEY);
          setToken(null);
        }
        return null;
      }
    } catch {
      return null;
    }
  };

  useEffect(() => {
    const initAuth = async () => {
      const currentUser = await fetchCurrentUser(token || '');
      setUser(currentUser);
      setIsLoading(false);
    };
    initAuth();
  }, [token]);

  const refreshUser = async () => {
    const currentUser = await fetchCurrentUser(token || '');
    setUser(currentUser);
  };

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Error al iniciar sesión' };
      }

      setToken(data.token);
      setUser(data.user);
      localStorage.setItem(TOKEN_KEY, data.token);
      setIsAuthModalOpen(false);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Error de conexión con el servidor' };
    }
  };

  const loginWithGoogleCredential = async (credential: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ credential }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data.error || 'Error verificando cuenta de Google' };
      }

      setToken(data.token);
      setUser(data.user);
      localStorage.setItem(TOKEN_KEY, data.token);
      setIsAuthModalOpen(false);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Error de conexión con el servidor' };
    }
  };

  const loginWithGoogleDemo = async (): Promise<{ success: boolean; error?: string }> => {
    return {
      success: false,
      error: 'Por favor utiliza el botón oficial de Google Identity Services con tu cuenta de Google.',
    };
  };

  const register = async (data: {
    email: string;
    password: string;
    fullName: string;
    phone?: string;
    address?: string;
    city?: string;
    department?: string;
  }): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const resData = await res.json();
      if (!res.ok) {
        return { success: false, error: resData.error || 'Error al crear la cuenta' };
      }

      setToken(resData.token);
      setUser(resData.user);
      localStorage.setItem(TOKEN_KEY, resData.token);
      setIsAuthModalOpen(false);
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Error de conexión' };
    }
  };

  const logout = async () => {
    if (token) {
      try {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}` },
        });
      } catch {}
    }
    setToken(null);
    setUser(null);
    localStorage.removeItem(TOKEN_KEY);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user,
        isLoading,
        isAuthModalOpen,
        authModalTab,
        googleClientId,
        isGoogleConfigured,
        openAuthModal,
        closeAuthModal,
        login,
        loginWithGoogleCredential,
        loginWithGoogleDemo,
        register,
        logout,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
